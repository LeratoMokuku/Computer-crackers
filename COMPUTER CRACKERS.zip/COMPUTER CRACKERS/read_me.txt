

Use the test program attached in our submission to test the program 
since it contains the instructions in our ISA design.

Also we have attached the frame of how the web-based simulator would
like as well as cpp implementation of a register file. 